const plus = document.querySelector('.js-plus');
const inpit = document.querySelector('.js-inpit')

console.log(123)